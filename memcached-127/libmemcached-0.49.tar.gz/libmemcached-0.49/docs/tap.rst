=================
Systemtap support
=================
 
By default on Linux libmemcached is compiled to support Systemtap. This enabled/disabled during compiles via the dtrace configure flag.

Please see :manpage: `stapex` for more information about Systemtap.
